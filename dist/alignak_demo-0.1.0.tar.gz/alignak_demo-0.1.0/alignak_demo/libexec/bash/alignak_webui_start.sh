#!/usr/bin/env bash
echo "Start Alignak WebUI..."
screen -d -S alignak_webui -m bash -c "cd /root/git/alignak-webui && ./bin/run.sh"
sleep 1
